package com.App.Restoran.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name = "APP_USER")
public class AppUser {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;

	
	private String fristname;
	private String lastname;
	private String username;
	private String password;
	private String confirmPassword;

	
	@Column(name = "SHORT_DESCRIPTION")
	private String description;

	@OneToMany(mappedBy = "appUser", cascade = CascadeType.ALL)
	private List<LagerLista> lagers = new ArrayList<>();

	
	public AppUser() {
		
	}



	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	public String getFristname() {
		return fristname;
	}



	public void setFristname(String fristname) {
		this.fristname = fristname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getConfirmPassword() {
		return confirmPassword;
	}



	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public List<LagerLista> getLagers() {
		return lagers;
	}



	public void setLagers(List<LagerLista> lagers) {
		this.lagers = lagers;
		 for (LagerLista lagerLista : lagers) {
		      lagerLista.setAppUser(this);
		    }
	}



	@Override
	public String toString() {
		return "AppUser [id=" + id + ", fristname=" + fristname + ", lastname=" + lastname + ", username=" + username
				+ ", password=" + password + ", confirmPassword=" + confirmPassword + ", description=" + description
				+ "]";
	}
	
	
}
