package com.App.Restoran.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.App.Restoran.Model.AppUser;
import com.App.Restoran.Service.AppUserService;


@Controller
@SessionAttributes(names = "user")
public class LoginController {

	
	@Autowired
	AppUserService userService;

	@GetMapping(path = "/login")
	public String getLogin() {
		return "login";
	}

	@PostMapping(path = "/login")
	public String postLogin(@RequestParam String username, @RequestParam String password, Model model) {
		List<AppUser> optUser = userService.getUser(username, password);
		if (!optUser.isEmpty()) {
			AppUser user = optUser.get(0);
			model.addAttribute("user", user);
			return "redirect:/boss";
		} else {
			model.addAttribute("errorMessage", "bad uername or password");
			return "login";
		}
	}

}
