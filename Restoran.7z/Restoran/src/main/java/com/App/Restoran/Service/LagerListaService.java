package com.App.Restoran.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.App.Restoran.Model.AppUser;
import com.App.Restoran.Model.LagerLista;
import com.App.Restoran.Repository.LagerListaRepository;


@Service
public class LagerListaService {

	@Autowired
	LagerListaRepository lRepo;

	public List<LagerLista> getLista(AppUser user) {
		return lRepo.findByAppUser(user);
	}

	public LagerLista saveLager(LagerLista Lista) {
		lRepo.save(Lista);
		return Lista;
	}
	

	}


