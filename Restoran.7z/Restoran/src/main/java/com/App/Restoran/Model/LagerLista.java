package com.App.Restoran.Model;

import javax.persistence.Table;



import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@Table (name = "LAGER_LISTA")
public class LagerLista {

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;
	private String artikal;
	private String quantiti;
	private String price;
	private String description;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "APP_USER_ID")
	private AppUser appUser;
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "WAITER_USER_ID")
	private WaiterUser waiterUser;
	

	public LagerLista() {
		
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getArtikal() {
		return artikal;
	}


	public void setArtikal(String artikal) {
		this.artikal = artikal;
	}


	public String getQuantiti() {
		return quantiti;
	}


	public void setQuantiti(String quantiti) {
		this.quantiti = quantiti;
	}


	public String getPrice() {
		return price;
	}


	public void setPrice(String price) {
		this.price = price;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	
	public AppUser getAppUser() {
		return appUser;
	}


	public void setAppUser(AppUser appUser) {
		this.appUser = appUser;
	}
	


	public WaiterUser getWaiterUser() {
		return waiterUser;
	}


	public void setWaiterUser(WaiterUser waiterUser) {
		this.waiterUser = waiterUser;
	}


	@Override
	public String toString() {
		return "LagerLista [id=" + id + ", artikal=" + artikal + ", quantiti=" + quantiti + ", price=" + price
				+ ", description=" + description + "]";
	}


	
	
	
	
}
