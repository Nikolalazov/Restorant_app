package com.App.Restoran.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.App.Restoran.Model.WaiterUser;
import com.App.Restoran.Repository.WaiterUserRepository;

@Service
public class WaiterUserService {

	
	@Autowired
	private WaiterUserRepository repo;

	public WaiterUser saveUser(WaiterUser user) {
		repo.save(user);
		return user;
	}

	public List<WaiterUser> getUser(String username, String password) {
		return repo.findByUsernameAndPassword(username, password);
	}

}
	
