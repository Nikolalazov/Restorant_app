package com.App.Restoran.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.App.Restoran.Model.AppUser;
import com.App.Restoran.Model.LagerLista;


public interface LagerListaRepository  extends JpaRepository<LagerLista, Long> {

	public List<LagerLista> findByDescription(String dscr);

	public List<LagerLista> findByAppUser(AppUser user);

	public List<LagerLista> findByAppUser_Id(Long id);
}
