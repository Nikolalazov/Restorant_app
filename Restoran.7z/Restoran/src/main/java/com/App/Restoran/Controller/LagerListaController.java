package com.App.Restoran.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.App.Restoran.Model.AppUser;
import com.App.Restoran.Model.LagerLista;
import com.App.Restoran.Service.LagerListaService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller 
@SessionAttributes(names = "user")
public class LagerListaController {

	@Autowired
	LagerListaService lagerService;
	
	@RequestMapping(path = "/lager-lista", method = RequestMethod.GET)
	public String getLagers(Model model) {
		if (model.getAttribute("user") == null) {
			model.addAttribute("errorMessage", "You are not logged in!");
			return "redirect:/";
		} else {
			AppUser user = (AppUser)model.getAttribute("user");
			List<LagerLista> lagers = lagerService.getLista(user);
			model.addAttribute("lagers", lagers);
			return "lager-lista";
		}
	}

	
	
}