package com.App.Restoran.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller
@SessionAttributes(names = "user")
public class BossController {


	@GetMapping(path = "/boss")
	public String getUsers(Model model) {
		if (model.getAttribute("user") == null) {
			model.addAttribute("errorMessage", "You are not logged in!");
			return "redirect:/";
		} else {
			return "boss";
		}
	}
	
	@PostMapping(path = "/boss")
	public String postUsers(Model model) {
		if (model.getAttribute("user") == null) {
			model.addAttribute("errorMessage", "You are not logged in!");
			return"redirect:/";
		}else {
			return "boss";
		}
	}

}
