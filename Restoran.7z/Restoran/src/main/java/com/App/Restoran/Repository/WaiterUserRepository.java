package com.App.Restoran.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.App.Restoran.Model.WaiterUser;

@Repository
public interface WaiterUserRepository extends JpaRepository<WaiterUser, Long> {


	List<WaiterUser> findByUsernameAndPassword(String username, String password);
	
}
