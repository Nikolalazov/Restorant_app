package com.App.Restoran;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.App.Restoran.Repository.AppUserRepository;
import com.App.Restoran.Repository.LagerListaRepository;



@SpringBootApplication
public class RestoranApplication {
	
	
	@Autowired
	private AppUserRepository userRepo;

	@Autowired
	private LagerListaRepository lagerRepo;
	
	public static void main(String[] args) {
		SpringApplication.run(RestoranApplication.class, args);
	}

}
