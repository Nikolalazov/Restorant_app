package com.App.Restoran.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.App.Restoran.Model.WaiterUser;

import com.App.Restoran.Service.WaiterUserService;

@Controller
@SessionAttributes(names = {"username","user"})
public class WaiterRegisterContorller {

	@Autowired
	private WaiterUserService service;

	@RequestMapping(path = "/waiter-register", method = RequestMethod.GET)
	public String getRegisterForm() {
		return "waiter-register";
	}

	@RequestMapping(path = "/waiter-register", method = RequestMethod.POST)
	public String registerUser(@RequestBody String body, WaiterUser waiterUser, Model model) {
		waiterUser = service.saveUser(waiterUser);
		model.addAttribute("username", waiterUser.getUsername());
		model.addAttribute("user", waiterUser);
		return "redirect:/";
	}

}
