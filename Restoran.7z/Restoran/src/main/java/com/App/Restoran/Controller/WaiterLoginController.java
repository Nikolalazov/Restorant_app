package com.App.Restoran.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.App.Restoran.Model.AppUser;
import com.App.Restoran.Model.WaiterUser;
import com.App.Restoran.Service.AppUserService;
import com.App.Restoran.Service.WaiterUserService;

@Controller
@SessionAttributes(names = "user")
public class WaiterLoginController {


	@Autowired
	WaiterUserService userService;

	@GetMapping(path = "/waiterlogin")
	public String getLogin() {
		return "login";
	}

	@PostMapping(path = "/waiterlogin")
	public String postLogin(@RequestParam String username, @RequestParam String password, Model model) {
		List<WaiterUser> optUser = userService.getUser(username, password); 
		if (!optUser.isEmpty()) {
			WaiterUser user = optUser.get(0);
			model.addAttribute("user", user);
			return "redirect:/tables";
		} else {
			model.addAttribute("errorMessage", "bad uername or password");
			return "waiterlogin";
		}
	}

}


