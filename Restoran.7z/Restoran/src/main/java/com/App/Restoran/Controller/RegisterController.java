package com.App.Restoran.Controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.App.Restoran.Model.AppUser;
import com.App.Restoran.Service.AppUserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
@SessionAttributes({"username","user"})
public class RegisterController {

	
	@Autowired
	private AppUserService service;

	@RequestMapping(path = "/register", method = RequestMethod.GET)
	public String getRegisterForm() {
		return "register";
	}

	@RequestMapping(path = "/register", method = RequestMethod.POST)
	public String registerUser(@RequestBody String body, AppUser appUser, Model model) {
		appUser = service.saveUser(appUser);
		model.addAttribute("username", appUser.getUsername());
		model.addAttribute("user", appUser);
		return "redirect:/";
	}

}
