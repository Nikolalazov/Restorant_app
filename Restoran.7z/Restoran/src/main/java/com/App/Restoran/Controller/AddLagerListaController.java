package com.App.Restoran.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.App.Restoran.Model.LagerLista;

import com.App.Restoran.Service.LagerListaService;

@Controller
@SessionAttributes(names = {"username","user"})
public class AddLagerListaController {

	@Autowired
	private LagerListaService service;

	@RequestMapping(path = "/addlager-lista", method = RequestMethod.GET)
	public String getRegisterForm() {
		return "addlager-lista";
	}

	@RequestMapping(path = "/addlager-lista", method = RequestMethod.POST)
	public String registerLagers(@RequestBody String body, LagerLista lagerLista, Model model) {
		lagerLista = service.saveLager(lagerLista);
		model.addAttribute("username", lagerLista.getArtikal());
		model.addAttribute("lagerLista", lagerLista);
		return "redirect:/";
	}

}

