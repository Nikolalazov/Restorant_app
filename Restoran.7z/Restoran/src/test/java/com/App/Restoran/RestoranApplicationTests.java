package com.App.Restoran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestoranApplicationTests {

	@Test
	void contextLoads() {
	}

}
